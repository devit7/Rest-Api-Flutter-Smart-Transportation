<?php

namespace App\Filament\Resources\HalteResource\Pages;

use App\Filament\Resources\HalteResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateHalte extends CreateRecord
{
    protected static string $resource = HalteResource::class;
}
